import app from '../server.js';
export default app;
